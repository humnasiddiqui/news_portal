<?php
require 'vendor/autoload.php';
include('includes/config.php');
include('C:\Users\HP\Downloads\Documents\htdocs\News_Portal\News_Portal\newsportal\category.php');
include('C:\Users\HP\Downloads\Documents\htdocs\News_Portal\News_Portal\example\scraping\BBC.php');
use Goutte\Client;

$client = new Client();
$crawler = $client->request('GET', 'https://www.bbc.com/news');



$titles = $crawler->filter('h1')->each(function ($node) {
  return $node->text();
});
?>