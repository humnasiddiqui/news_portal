<?php
require 'simple_html_dom.php';?>

<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        h1 {
            text-align: center;
        }

        h3 {
            margin-top: 20px;
        }

        img {
            display: block;
            margin: 20px auto;
            max-width: 100%;
            height: auto;
        }

        .article {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 20px;
        }

        .article h4 {
            margin-top: 10px;
        }

        .article p {
            margin-bottom: 10px;
        }

        .article hr {
            border: none;
            border-top: 1px solid #ccc;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <?php

function scraping_bbc() {
    // Create HTML DOM for BBC News
    $html = get_html_with_user_agent('https://www.bbc.com/news');

    // Get news blocks
    $ret = [];
    foreach ($html->find('.gs-c-promo') as $article) {
        // Get title
        $titleElement = $article->find('.gs-c-promo-heading', 0);
        $title = $titleElement ? trim($titleElement->plaintext) : '';

        // Get details
        $detailsElement = $article->find('.gs-c-promo-summary', 0);
        $details = $detailsElement ? trim($detailsElement->plaintext) : '';

        // Get image URL
        $imageElement = $article->find('img', 0);
        $imageUrl = $imageElement ? $imageElement->getAttribute('src') : '';

        // Get important content
        $importantContent = '';
        $contentElement = $article->find('.gs-c-promo-summary', 0);
        if ($contentElement) {
            $importantContent = $contentElement->plaintext;
        }

        $ret[] = [
            'source' => 'BBC News',
            'title' => $title,
            'details' => $details,
            'imageUrl' => $imageUrl,
            'importantContent' => $importantContent
        ];
    }

    // Clean up memory
    $html->clear();
    unset($html);

    return $ret;
}

function get_html_with_user_agent($url) {
    $context = stream_context_create([
        'http' => [
            'header' => 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.71 Safari/537.36'
        ]
    ]);
    $html = file_get_html($url, false, $context);
    return $html;
}

// Scrape BBC News
$bbc_data = scraping_bbc();

// Output the scraped data


echo '<br><br>
<br><br>
<h1>BBC News</h1>';
foreach ($bbc_data as $data) {
    echo '<br><h3>' . $data['title'] . '</h3>';
    if (!empty($data['imageUrl'])) {
        echo '<img src="' . $data['imageUrl'] . '" alt="' . $data['title'] . '"><br>';
    }
    echo '<h4>Important Content:</h4>';
    echo '<p>' . $data['details'] . '</p>';
    // echo '<p>' . $data['importantContent'] . '</p>';
    echo '<hr>';
}

?>